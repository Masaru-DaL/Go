# Changes

## 1.0.0

Stabilize GA surface.

## [0.2.0](https://www.github.com/googleapis/google-cloud-go/compare/functions/v0.1.0...functions/v0.2.0) (2021-09-16)


### Features

* **functions:** add SecurityLevel option on HttpsTrigger ([8ffed36](https://www.github.com/googleapis/google-cloud-go/commit/8ffed36c9db818a24073cf865f626d29afd01716))

## v0.1.0

This is the first tag to carve out functions as its own module. See
[Add a module to a multi-module repository](https://github.com/golang/go/wiki/Modules#is-it-possible-to-add-a-module-to-a-multi-module-repository).
