// Copyright (c) 2017-2019 Snowflake Computing Inc. All right reserved.

package gosnowflake

// SnowflakeGoDriverVersion is the version of Go Snowflake Driver.
const SnowflakeGoDriverVersion = "1.6.3"
