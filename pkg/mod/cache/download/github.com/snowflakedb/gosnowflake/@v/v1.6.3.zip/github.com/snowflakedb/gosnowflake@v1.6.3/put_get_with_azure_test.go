// Copyright (c) 2021 Snowflake Computing Inc. All right reserved.

package gosnowflake
