package main

import (
	"fmt"

	// comment
	g "github.com/golang" // comment

	"github.com/daixiang0/gci"
)
