package main

import (
	"fmt"

	g "github.com/golang"
	. "github.com/golang/dot"
	_ "github.com/golang/blank"

	"github.com/daixiang0/a"
	"github.com/daixiang0/gci"
	"github.com/daixiang0/gci/subtest"
	. "github.com/daixiang0/gci/dot"
	_ "github.com/daixiang0/gci/blank"
)
