package utils

const (
	Indent    = '\t'
	Linebreak = '\n'

	Colon = ":"

	LeftParenthesis  = '('
	RightParenthesis = ')'
)
