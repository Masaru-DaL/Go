package main

import (
	// https://pkg.go.dev/fmt
	"fmt"
	"os" // https://pkg.go.dev/os
)
