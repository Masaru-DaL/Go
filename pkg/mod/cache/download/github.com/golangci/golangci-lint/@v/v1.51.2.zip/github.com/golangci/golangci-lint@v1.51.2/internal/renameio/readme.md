# renameio

Extracted from go/src/cmd/go/internal/renameio/
I don't know what version of Go this package was pulled from.

Adapted for golangci-lint:
- https://github.com/golangci/golangci-lint/pull/699
- https://github.com/golangci/golangci-lint/pull/808
- https://github.com/golangci/golangci-lint/pull/1063
- https://github.com/golangci/golangci-lint/pull/3204
