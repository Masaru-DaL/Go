// Copyright 2011-2012 Branimir Karadzic. All rights reserved.
// Copyright 2013 Damian Gryski. All rights reserved.

// @LINK: https://github.com/bkaradzic/go-lz4
// @NOTE: The code is modified to be high performance and less memory usage

package lz4
