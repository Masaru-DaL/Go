package _generated

//go:generate msgp

type Issue191 struct {
	Foo string
	Bar string
}
