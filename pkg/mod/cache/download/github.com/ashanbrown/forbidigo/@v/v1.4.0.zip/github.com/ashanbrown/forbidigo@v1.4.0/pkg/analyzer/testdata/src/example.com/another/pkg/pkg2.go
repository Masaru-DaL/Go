package pkg

import "example.com/some/pkg"

type CustomTypeAlias = pkg.CustomType
