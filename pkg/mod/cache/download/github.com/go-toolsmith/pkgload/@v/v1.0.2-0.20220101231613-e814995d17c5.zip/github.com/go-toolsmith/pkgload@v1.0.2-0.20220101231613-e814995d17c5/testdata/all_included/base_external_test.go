package allincluded_test

import "testing"

func TestExternal(t *testing.T) {}
