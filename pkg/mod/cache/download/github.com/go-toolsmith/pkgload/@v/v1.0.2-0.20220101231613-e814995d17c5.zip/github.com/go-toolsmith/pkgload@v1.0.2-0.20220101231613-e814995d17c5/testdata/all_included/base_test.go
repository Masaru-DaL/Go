package allincluded

import "testing"

func TestSimple(t *testing.T) {}
