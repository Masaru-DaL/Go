package allincluded

func f() {

}
