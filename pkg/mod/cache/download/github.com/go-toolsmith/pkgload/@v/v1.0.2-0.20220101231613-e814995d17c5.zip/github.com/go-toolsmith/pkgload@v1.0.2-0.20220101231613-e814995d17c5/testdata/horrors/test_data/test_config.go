package client_test

const Horror = true
