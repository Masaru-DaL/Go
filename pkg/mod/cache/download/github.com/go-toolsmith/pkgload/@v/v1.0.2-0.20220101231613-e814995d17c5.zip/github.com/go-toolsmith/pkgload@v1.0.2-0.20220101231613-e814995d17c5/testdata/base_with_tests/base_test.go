package basewithtests

import "testing"

func Test(t *testing.T) {}
