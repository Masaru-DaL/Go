// +build js

package testing
