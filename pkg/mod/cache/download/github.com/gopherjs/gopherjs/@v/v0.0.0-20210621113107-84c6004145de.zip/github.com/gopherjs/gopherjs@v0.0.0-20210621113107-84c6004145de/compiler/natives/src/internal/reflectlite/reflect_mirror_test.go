// +build js

package reflectlite_test

import (
	"testing"
)

func TestMirrorWithReflect(t *testing.T) {
	t.Skip("TestMirrorWithReflect")
}
