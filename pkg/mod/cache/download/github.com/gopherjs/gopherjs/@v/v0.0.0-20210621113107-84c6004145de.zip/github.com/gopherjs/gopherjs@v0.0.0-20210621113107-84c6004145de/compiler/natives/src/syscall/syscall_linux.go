// +build js

package syscall

const exitTrap = SYS_EXIT_GROUP
