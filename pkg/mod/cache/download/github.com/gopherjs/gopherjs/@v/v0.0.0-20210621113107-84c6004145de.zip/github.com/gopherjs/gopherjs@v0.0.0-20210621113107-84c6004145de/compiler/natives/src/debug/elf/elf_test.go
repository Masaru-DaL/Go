// +build js

package elf

import "testing"

func TestNoSectionOverlaps(t *testing.T) {
	t.Skip("not 6l")
}
