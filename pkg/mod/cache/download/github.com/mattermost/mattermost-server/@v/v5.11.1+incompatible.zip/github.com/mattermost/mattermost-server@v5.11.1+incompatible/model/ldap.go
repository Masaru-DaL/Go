// Copyright (c) 2016-present Mattermost, Inc. All Rights Reserved.
// See License.txt for license information.

package model

const (
	USER_AUTH_SERVICE_LDAP = "ldap"
)
