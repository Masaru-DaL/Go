Please see Mattermost Documentation now at [http://docs.mattermost.com](http://docs.mattermost.com)
