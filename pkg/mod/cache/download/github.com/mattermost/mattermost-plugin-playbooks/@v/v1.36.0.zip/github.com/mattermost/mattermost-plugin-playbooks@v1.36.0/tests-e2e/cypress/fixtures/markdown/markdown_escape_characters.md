### Escaped Characters

**The following text should render the same as the raw text:**
Raw: `\\teamlinux\IT-Stuff\WorkingStuff`
Markdown: \\teamlinux\IT-Stuff\WorkingStuff

**The following text should escape out the first backslash so only one backslash appears:**
Raw: `\\()#`
Markdown: \\()#

The end of this long post will be hidden until you choose to `Show More`.
