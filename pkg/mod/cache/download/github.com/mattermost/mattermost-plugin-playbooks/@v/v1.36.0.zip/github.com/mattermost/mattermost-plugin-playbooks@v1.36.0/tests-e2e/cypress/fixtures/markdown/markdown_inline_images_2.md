### In-line Images

GitHub favicon:  ![Github](https://github.githubassets.com/favicon.ico)
