### Carriage Return

Line #1 followed by one blank line

Line #2 followed by one blank line

Line #3 followed by Line #4
Line #4
