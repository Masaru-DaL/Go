ALTER TABLE IR_Incident DROP COLUMN IF EXISTS ConcatenatedInvitedGroupIDs;
