### In-line Code

The word `monospace` should render as in-line code.

The following markdown in-line code should not render:
`_Italics_`, `*Italics*`, `**Bold**`, `***Bold-italics***`, `**Bold-italics_**`, `~~Strikethrough~~`, `:)` , `:-)` , `;)` , `:-O` , `:bamboo:` , `:gift_heart:` , `:dolls:` , `# Heading 1`, `## Heading 2`, `### Heading 3`, `#### Heading 4`, `##### Heading 5`, `###### Heading 6`

This GIF link should not preview: `http://i.giphy.com/xNrM4cGJ8u3ao.gif`
This link should not auto-link: `https://en.wikipedia.org/wiki/Dolphin`

This sentence with `
in-line code
` should appear on one line.
