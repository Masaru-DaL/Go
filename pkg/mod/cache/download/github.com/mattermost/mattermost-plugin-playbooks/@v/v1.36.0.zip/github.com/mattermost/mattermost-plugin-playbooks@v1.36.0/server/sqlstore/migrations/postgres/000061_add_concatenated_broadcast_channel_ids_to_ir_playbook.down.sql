ALTER TABLE IR_Playbook DROP COLUMN IF EXISTS ConcatenatedBroadcastChannelIds;
ALTER TABLE IR_Playbook DROP COLUMN IF EXISTS BroadcastEnabled;
