ALTER TABLE IR_Playbook DROP COLUMN IF EXISTS AnnouncementChannelEnabled;
