### In-line Images

GIF Image:
![gif](http://i.giphy.com/xNrM4cGJ8u3ao.gif)
