ALTER TABLE IR_Playbook ADD COLUMN IF NOT EXISTS ConcatenatedSignalAnyKeywords TEXT DEFAULT '';
