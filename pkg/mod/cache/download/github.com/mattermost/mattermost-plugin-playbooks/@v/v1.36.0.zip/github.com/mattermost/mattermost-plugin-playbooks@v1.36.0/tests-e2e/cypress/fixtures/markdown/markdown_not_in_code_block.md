**The following markdown should not render:**
```
_Italics_
*Italics*
**Bold**
***Bold-italics***
**Bold-italics_**
~~Strikethrough~~
:) :-) ;) ;-) :o :O :-o :-O
:bamboo: :gift_heart: :dolls: :school_satchel: :mortar_board:
# Heading 1
## Heading 2
### Heading 3
#### Heading 4
##### Heading 5
###### Heading 6
> Block Quote
- List
  - List Sub-item
[Link](http://i.giphy.com/xNrM4cGJ8u3ao.gif)
[![Github](https://assets-cdn.github.com/favicon.ico)](https://github.com/mattermost/platform)
| Left-Aligned Text | Center Aligned Text | Right Aligned Text |
| :------------ |:---------------:| -----:|
| Left column 1 | this text       |  $100 |
```
