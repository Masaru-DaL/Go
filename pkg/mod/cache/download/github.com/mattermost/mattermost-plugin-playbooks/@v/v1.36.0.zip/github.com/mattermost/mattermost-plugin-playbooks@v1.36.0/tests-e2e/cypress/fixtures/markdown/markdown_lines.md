### Lines

Three lines should render with text between them:

Text above line

***

Text between lines

---

Text between lines
___

Text below line
