```texcode
\documentclass{article}

\begin{document}

Hello World!

\end{document}
```

AND/OR

```latexcode
\documentclass{article}

\begin{document}

Hello World!

\end{document}
```