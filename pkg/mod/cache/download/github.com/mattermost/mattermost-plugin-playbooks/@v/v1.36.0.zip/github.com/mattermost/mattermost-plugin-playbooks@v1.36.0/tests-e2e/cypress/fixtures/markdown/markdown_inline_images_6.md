### In-line Images

![test image](https://www.mattermost.org/wp-content/uploads/2016/03/logoHorizontal.png)
