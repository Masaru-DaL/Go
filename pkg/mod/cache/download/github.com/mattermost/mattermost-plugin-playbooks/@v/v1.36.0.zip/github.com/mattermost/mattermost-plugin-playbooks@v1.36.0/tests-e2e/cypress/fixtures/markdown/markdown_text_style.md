### Text Style

**The following text should render as:**
_Italics_
_Ita_lics_
*Italics*
**Bold**
***Bold-italics***
**_Bold-italics_**
~~Strikethrough~~

This sentence contains **bold**, _italic_, ***bold-italic***, and ~~strikethrough~~ text.

**The following should render as normal text:**
Normal Text_
_Normal Text
_Normal Text*
