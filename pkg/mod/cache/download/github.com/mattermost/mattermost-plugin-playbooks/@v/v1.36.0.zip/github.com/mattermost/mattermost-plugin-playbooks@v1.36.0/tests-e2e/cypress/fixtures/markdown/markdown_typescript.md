```ts
const message: string = 'hello world';
console.log(message);
```
and

```tsx
const message: string = 'hello world';
console.log(message);
```

and

```typescript
const message: string = 'hello world';
console.log(message);
```