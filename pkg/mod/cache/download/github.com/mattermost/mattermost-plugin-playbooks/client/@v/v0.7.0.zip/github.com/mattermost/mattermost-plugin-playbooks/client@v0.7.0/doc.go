// Copyright (c) 2015-present Mattermost, Inc. All Rights Reserved.
// See LICENSE.txt for license information.

// Package client provides an HTTP client for using the Playbooks API.
package client
