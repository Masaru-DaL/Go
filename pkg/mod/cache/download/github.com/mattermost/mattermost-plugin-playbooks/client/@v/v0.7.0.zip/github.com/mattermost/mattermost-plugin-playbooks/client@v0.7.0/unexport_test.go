package client

var BuildAPIURL = buildAPIURL
var NewClient = newClient
