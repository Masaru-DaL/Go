// package i18n provides methods to read translations files and localize strings.
package i18n
