// package cluster exposes synchronization primitives to ensure correct behavior across multiple
// plugin instances in a Mattermost cluster.
package cluster
