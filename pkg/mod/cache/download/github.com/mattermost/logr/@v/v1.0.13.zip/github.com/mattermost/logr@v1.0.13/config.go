package logr

import (
	"fmt"

	"github.com/wiggin77/cfg"
)

func ConfigLogger(config *cfg.Config) error {
	return fmt.Errorf("Not implemented yet")
}
