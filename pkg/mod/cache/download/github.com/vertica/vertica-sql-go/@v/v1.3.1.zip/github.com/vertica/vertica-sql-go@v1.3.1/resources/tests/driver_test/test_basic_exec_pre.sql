DROP TABLE IF EXISTS MyTable;
CREATE TABLE MyTable (id int, name varchar(64), PRIMARY KEY(id));
