-- Drop all authentication stuff.
DROP AUTHENTICATION v_hash CASCADE;
