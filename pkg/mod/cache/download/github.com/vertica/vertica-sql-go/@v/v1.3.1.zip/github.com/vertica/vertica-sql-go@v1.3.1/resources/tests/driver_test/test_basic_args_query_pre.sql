DROP TABLE IF EXISTS MyTable;
CREATE TABLE MyTable(id int, name VARCHAR(64), guitarist BOOLEAN, height FLOAT, birthday TIMESTAMP, PRIMARY KEY(id));
