These specs have been generated from the testsuite in [graphql/graph-js](https://github.com/graphql/graphql-js).

Direct modifications should not be made, instead take a look at the exporter.