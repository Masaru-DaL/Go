package checker_test

//line /foo/bar.go:10

//line /foo/bar/f-ad/a_d.go:13
//line /bar.go:14
