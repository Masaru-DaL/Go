# merror

[![GoDoc](https://godoc.org/github.com/wiggin77/merror?status.svg)](https://godoc.org/github.com/wiggin77/merror)
[![Build Status](https://travis-ci.org/wiggin77/merror.svg?branch=master)](https://travis-ci.org/wiggin77/merror)

Multiple Error aggregator for Go.
