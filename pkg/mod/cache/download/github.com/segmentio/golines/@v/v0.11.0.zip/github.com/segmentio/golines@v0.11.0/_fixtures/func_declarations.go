package fixtures

func shortDec(a int, b int) int {
	return 5
}

func longLine2(aReallyLongName string, anotherLongName string, aThirdLongName string) (string, string, error) {
	return "", "", nil
}

func longLine3(aReallyLongName string,
	anotherLongName string, aThirdLongName string, aFourthLongName string, aFifthLongName string) (string, string, error) {
	return "", "", nil
}
