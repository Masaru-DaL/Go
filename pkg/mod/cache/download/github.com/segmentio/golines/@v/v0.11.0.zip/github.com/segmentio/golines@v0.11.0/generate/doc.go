/*
Command generate is used to generate code that creates dot files from golang ASTs.
*/
package main // import "github.com/segmentio/golines/generate"
