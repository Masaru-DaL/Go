// Package fixtures contains made-up go files used for testing golines
// under various conditions.
package fixtures
