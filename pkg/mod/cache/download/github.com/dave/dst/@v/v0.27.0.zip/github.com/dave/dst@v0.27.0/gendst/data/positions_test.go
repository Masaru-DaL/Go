package data

import "testing"

func Test(t *testing.T) {
	// just test this package compiles
}
