package followschema

type FieldsOrderInput struct {
	FirstField *string `json:"firstField"`
}
