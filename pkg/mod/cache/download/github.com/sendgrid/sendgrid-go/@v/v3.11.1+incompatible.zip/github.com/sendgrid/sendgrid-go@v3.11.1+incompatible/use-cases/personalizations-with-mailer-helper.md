## Personalizations - With Mail Helper Class

* [Sending a Single Email to a Single Recipient](personalization-sending-single-email-single-recipient.md)
* [Sending a Single Email to a Single Recipient with a CC](personalization-sending-single-email-single-recipient-with-cc.md)
* [Sending a Single Email to a Single Recipient with a CC and a BCC](personalization-sending-single-email-single-recipient-with-cc-bcc.md)
* [Sending a Single Email to Multiple Recipients](personalization-sending-single-email-to-multiple-recipients.md)
* [Sending a Single Email to a Single Recipient with Multiple CCs/BCCs](personalization-sending-single-email-to-single-recipients-with-multiple-cc-bcc.md)
* [Sending Two Different Emails to Two Different Groups of Recipients](personalization-sending-two-emails-to-two-groups-recipients.md)
* [Sending Two Different Emails to Two Different Groups of Recipients from two different From email addresses ](personalization-sending-two-emails-to-two-groups-recipients-from-two-different-from-emails.md)