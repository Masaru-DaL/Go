# Personalizations

* [With Mail Helper Class](personalizations-with-mailer-helper.md)
* [Without Mail Helper Class](personalizations-without-mailer-helper.md)