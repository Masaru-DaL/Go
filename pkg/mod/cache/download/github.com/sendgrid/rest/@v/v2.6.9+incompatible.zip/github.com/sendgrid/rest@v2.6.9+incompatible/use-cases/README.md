This document provides examples for specific SendGrid v3 API use cases. Please [open an issue](https://github.com/sendgrid/rest/issues) or make a pull request for any email use cases you would like us to document here. Thank you!

# Email Use Cases

# Non-mail Use Cases
