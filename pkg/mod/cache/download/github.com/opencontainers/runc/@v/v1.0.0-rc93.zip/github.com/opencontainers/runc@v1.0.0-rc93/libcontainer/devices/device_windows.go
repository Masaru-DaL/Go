package devices

func (d *Rule) Mkdev() (uint64, error) {
	return 0, nil
}
