CREATE INDEX ON public.users (user_id);
