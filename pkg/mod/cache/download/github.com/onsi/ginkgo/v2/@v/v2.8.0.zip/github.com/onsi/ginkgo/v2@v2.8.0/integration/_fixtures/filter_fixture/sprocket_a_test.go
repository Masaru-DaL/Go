package filter_fixture_test

import (
	. "github.com/onsi/ginkgo/v2"
)

var _ = Describe("SprocketA", func() {
	It("cat", func() {

	})

	PIt("pending dog", func() {

	})

	It("cat fish", func() {

	})

	It("dog fish", func() {

	})
})
