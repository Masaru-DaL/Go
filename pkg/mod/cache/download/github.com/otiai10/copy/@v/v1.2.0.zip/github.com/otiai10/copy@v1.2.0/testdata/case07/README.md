# Case 07: Add Permission

`Options.AddPermission` should add permission to all the dirs and files, if specified.