# Changelog

## 1.0.0 (2021-04-07)


### Features

* Adapters for Color, Date, DateTime, Decimal, Fraction, Month ([#1](https://www.github.com/googleapis/go-type-adapters/issues/1)) ([67144ff](https://www.github.com/googleapis/go-type-adapters/commit/67144ff619d74444ff926f76fd198c9a616b0faa))
