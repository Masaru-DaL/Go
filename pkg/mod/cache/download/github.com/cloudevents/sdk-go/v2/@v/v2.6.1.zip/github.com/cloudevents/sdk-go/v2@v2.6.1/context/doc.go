/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package context holds the last resort overrides and fyi objects that can be passed to clients and transports added to
context.Context objects.
*/
package context
