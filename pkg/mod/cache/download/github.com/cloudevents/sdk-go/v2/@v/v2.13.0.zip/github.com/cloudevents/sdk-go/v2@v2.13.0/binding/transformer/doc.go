/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

// Package transformer provides methods for creating event message transformers.
package transformer
