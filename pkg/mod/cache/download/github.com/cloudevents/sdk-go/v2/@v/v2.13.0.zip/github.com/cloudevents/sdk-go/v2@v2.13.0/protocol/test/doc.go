/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

package test

/*
Package test provides utilities to test binding implementations and transformers.

*/
