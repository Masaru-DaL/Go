/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package test has utilities (asserts, mocks, ...) to use cloudevents in your tests
*/
package test
