/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package event provides primitives to work with CloudEvents specification: https://github.com/cloudevents/spec.
*/
package event
