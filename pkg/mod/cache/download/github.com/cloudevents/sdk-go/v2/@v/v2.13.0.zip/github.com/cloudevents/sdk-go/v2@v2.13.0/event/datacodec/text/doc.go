/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package text holds the encoder/decoder implementation for `text/plain`.
*/
package text
