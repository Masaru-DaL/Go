/*
 Copyright 2021 The CloudEvents Authors
 SPDX-License-Identifier: Apache-2.0
*/

/*
Package observability holds metrics and tracing common keys.
*/
package observability
