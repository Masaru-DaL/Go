// Package http implements an HTTP CloudEvents binding.
package http

// TODO(alanconway, slinkydeveloper)
// - different kinds of sender/receiver: long poll, event as response, etc.
// - review blocking, error handling, closing.
