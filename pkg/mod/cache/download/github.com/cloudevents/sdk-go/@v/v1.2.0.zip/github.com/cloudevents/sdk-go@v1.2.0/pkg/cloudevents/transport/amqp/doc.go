/*
Package amqp implements the CloudEvent transport implementation using amqp.
*/
package amqp

// TODO(alanconway) deprecated, use bindings/amqp directly
