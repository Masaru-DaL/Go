/*
Package amqp implements an AMQP binding.
*/
package amqp

// TODO(slinkydeveloper)
