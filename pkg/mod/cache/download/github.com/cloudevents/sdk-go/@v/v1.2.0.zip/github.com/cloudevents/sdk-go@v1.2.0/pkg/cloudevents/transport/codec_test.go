package transport_test

import (
	"testing"
)

func TestCodec(t *testing.T) {
	// TODO: add a test. This makes coverage count this dir.
}
