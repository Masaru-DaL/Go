/*
Package http implements the CloudEvent transport implementation using HTTP.
*/
package http
