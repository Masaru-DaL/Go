/*
Package nats implements the CloudEvent transport implementation using NATS.
*/
package nats
