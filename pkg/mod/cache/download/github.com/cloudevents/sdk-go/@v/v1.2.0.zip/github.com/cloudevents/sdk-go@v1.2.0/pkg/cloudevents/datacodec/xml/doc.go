/*
Package xml holds the encoder/decoder implementation for `application/xml`.
*/
package xml
