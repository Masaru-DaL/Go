/*
Package cloudevents provides primitives to work with CloudEvents specification: https://github.com/cloudevents/spec.
*/
package cloudevents
