// Package kafka implements the Kafka CloudEvents binding.
package kafka_sarama

// TODO(slinkydeveloper)
