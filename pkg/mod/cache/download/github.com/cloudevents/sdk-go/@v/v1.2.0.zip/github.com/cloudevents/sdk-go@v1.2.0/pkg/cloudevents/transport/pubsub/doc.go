/*
Package pubsub implements the CloudEvent transport implementation using pubsub.
*/
package pubsub
