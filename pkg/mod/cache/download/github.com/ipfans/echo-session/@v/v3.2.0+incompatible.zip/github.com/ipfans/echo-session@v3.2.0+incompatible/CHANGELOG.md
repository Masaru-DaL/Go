# CHANGELOGS

<a name="v3.2.0"></a>
## [v3.2.0](https://github.com/ipfans/echo-session/compare/v3.1.1...v3.2.0) (2018-07-20)
FEATURE: Support Redis db selection.
BUGFIX: #7 Update redigo client library.

<a name="v3.1.1"></a>
## [v3.1.1](https://github.com/ipfans/echo-session/compare/v3.1.0...v3.1.1) (2017-07-17)


<a name="v3.1.0"></a>
## [v3.1.0](https://github.com/ipfans/echo-session/compare/v3.0.0-rc1...v3.1.0) (2017-07-12)


<a name="v3.0.0-rc1"></a>
## [v3.0.0-rc1](https://github.com/ipfans/echo-session/compare/v2.0.0-rc1...v3.0.0-rc1) (2017-03-09)


<a name="v2.0.0-rc1"></a>
## v2.0.0-rc1 (2017-03-09)