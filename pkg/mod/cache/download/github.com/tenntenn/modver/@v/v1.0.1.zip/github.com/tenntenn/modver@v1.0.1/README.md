# modver
[![PkgGoDev](https://pkg.go.dev/badge/github.com/tenntenn/modver)](https://pkg.go.dev/github.com/tenntenn/modver)

`modver` is utility for Go Modules.
