// Copyright (c) 2014 The mathutil Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

package mathutil // import "modernc.org/mathutil"

// Pull test dependencies too.
// Enables easy 'go test X' after 'go get X'
import (
// nothing yet
)
