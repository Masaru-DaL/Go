int j;

void residual ()
{
  long double s;
  for (j = 3; j < 9; j++)
    s -= 3;
}
