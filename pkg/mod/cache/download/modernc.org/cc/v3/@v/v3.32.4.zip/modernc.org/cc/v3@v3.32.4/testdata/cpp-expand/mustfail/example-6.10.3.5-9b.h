#define OBJ_LIKE (1-1)
#define OBJ_LIKE (1 - 1) // different white space
