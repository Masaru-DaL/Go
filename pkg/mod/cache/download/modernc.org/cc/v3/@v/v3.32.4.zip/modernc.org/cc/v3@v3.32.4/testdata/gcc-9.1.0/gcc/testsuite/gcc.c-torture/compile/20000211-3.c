void f_clos(int x)

{        
        switch(x) {
                default:
                mumble:;
        }
}


