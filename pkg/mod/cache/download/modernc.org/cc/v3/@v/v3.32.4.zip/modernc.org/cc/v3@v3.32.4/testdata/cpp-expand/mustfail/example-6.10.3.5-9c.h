#define FUNC_LIKE(a) ( a )
#define FUNC_LIKE(b) ( a ) // different parameter usage
