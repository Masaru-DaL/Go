typedef enum {a, b} __attribute__((__mode__(__QI__))) x;
x foo;
