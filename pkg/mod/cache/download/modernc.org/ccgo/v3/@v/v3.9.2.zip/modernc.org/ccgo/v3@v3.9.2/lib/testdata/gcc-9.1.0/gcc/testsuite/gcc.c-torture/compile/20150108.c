long long a[10];
long long b, c, d, k, m, n, o, p, q, r, s, t, u, v, w;
int e, f, g, h, i, j, l, x;

int fn1 () {
  for (; x; x++)
    if (x & 1)
      s = h | g;
    else
      s = f | e;
  l = ~0;
  m = 1 | k;
  n = i;
  o = j;
  p = f | e;
  q = h | g;
  w = d | c | a[1];
  t = c;
  v = b | c;
  u = v;
  r = b | a[4];
  return e;
}
