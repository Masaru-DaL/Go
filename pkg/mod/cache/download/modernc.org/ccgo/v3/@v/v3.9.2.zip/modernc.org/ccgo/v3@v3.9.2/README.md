# ccgo/v3

Command ccgo is a C compiler targeting Go.

Installation

    $ go get -u modernc.org/ccgo/v3

Documentation: [godoc.org/modernc.org/ccgo/v3](http://godoc.org/modernc.org/ccgo/v3)
