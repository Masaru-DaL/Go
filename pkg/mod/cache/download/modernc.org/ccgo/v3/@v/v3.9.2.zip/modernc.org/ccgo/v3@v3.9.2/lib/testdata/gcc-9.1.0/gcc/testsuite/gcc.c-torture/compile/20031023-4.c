#define ASIZE 0x80000000UL
#include "20031023-1.c"
